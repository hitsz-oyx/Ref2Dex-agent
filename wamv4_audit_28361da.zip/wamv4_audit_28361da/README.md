# WAM-v4 audit bundle

Target: `hitsz-oyx/Ref2Dex-agent@28361dace28323a318f2d0bc3aa043bbae298b8a`.

Read `审计报告.md` first. `sources.json` records the inspected source identities.

The Python scripts reproduce selected source semantics using synthetic CPU fixtures.
They do not clone/import the complete repository, run NCCL/DDP processes, inspect the user's datasets, or execute a robot simulator.

```bash
python reproduce_objectives.py
python reproduce_data_contracts.py
```

`objective_repro_results.json` and `data_repro_results.json` contain the results generated in this conversation.

No remote repository files, training processes, or datasets were modified.
