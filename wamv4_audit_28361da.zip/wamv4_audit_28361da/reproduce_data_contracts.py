"""Isolated CPU checks of source excerpts at commit 28361da.

No private datasets, robot runtime, CUDA, or full repository imports are used.
This file checks the exact local semantics of the current source routines.
"""
from pathlib import Path
from dataclasses import dataclass
import json
import tempfile
import numpy as np

PART_DIM = 6
SCAFFOLD_SEGMENTS = ((0,1,0),(0,2,0),(0,3,0),(0,4,0),(0,5,0),
                     (1,6,1),(2,7,2),(3,8,3),(4,9,4),(5,10,5))
@dataclass(frozen=True)
class Policy:
    voxel_m: float=.01

def _voxel(points, origin, voxel_m):
    return np.floor((points-origin)/voxel_m).astype(np.int64)

# Source-excerpt implementation of the corrected _scaffold().
def _scaffold(hand, valid, origin, policy):
    points, parts = [], []
    for side in range(hand.shape[0]):
        for key, ok in enumerate(valid[side]):
            if ok:
                part = 0 if key == 0 else (1 if key in (1, 6) else
                                           2 if key in (2, 7) else
                                           3 if key in (3, 8) else
                                           4 if key in (4, 9) else 5)
                points.append(hand[side,key]);parts.append(part)
        for a,b,part in SCAFFOLD_SEGMENTS:
            if not (valid[side,a] and valid[side,b]):continue
            start,end=hand[side,a],hand[side,b]
            length=float(np.linalg.norm(end-start))
            n=max(2,int(np.ceil(length/policy.voxel_m))+1)
            line=start[None]+np.linspace(0,1,n)[:,None]*(end-start)[None]
            points.append(line);parts.extend([part]*n)
    if not points:return np.empty((0,3),np.int64),np.empty((0,PART_DIM),np.float32)
    voxels=_voxel(np.concatenate([p if p.ndim==2 else p[None] for p in points]),origin,policy.voxel_m)
    unique,inverse=np.unique(voxels,axis=0,return_inverse=True)
    counts=np.zeros((len(unique),PART_DIM),np.float32)
    np.add.at(counts,(inverse,np.asarray(parts,np.int64)),1.)
    return unique,counts

# Exact frame-validity block from interaction_field(), extracted for isolation.
def frame_mask(hand_valid, active_sides=None):
    future_active=hand_valid.any(axis=(0,2))
    if active_sides is None:active_sides=future_active
    else:
        active_sides=np.asarray(active_sides,bool)
        if active_sides.shape!=(2,):raise ValueError('active hand sides must have shape (2,)')
        active_sides=active_sides|future_active
    frame_valid=np.zeros(len(hand_valid),bool)
    if active_sides.any():frame_valid=hand_valid[:,active_sides].all(axis=(1,2))
    return frame_valid

# Source-excerpt implementation of apply_surface_overlay().
SCHEMA='ref2dex.wam-v4-dense-surface.v1'
def apply_surface_overlay(geometry,path):
    path=Path(path);manifest=json.loads(path.read_text())
    if manifest.get('schema')!=SCHEMA or manifest.get('status')!='COMPLETED':
        raise ValueError('completed v4 dense surface manifest required')
    seen=set()
    for row in manifest['objects']:
        key=row['key']
        if key not in geometry or key in seen:raise ValueError('unknown or duplicated dense surface identity: '+key)
        with np.load(path.parent/row['path'],allow_pickle=False) as values:
            replacement={key:values[key].copy() for key in values.files}
        if (replacement['surface'].shape!=(512,3)
                or len(np.unique(replacement['surface'],axis=0))!=512
                or replacement['normals'].shape!=(512,3)
                or not np.isfinite(replacement['surface']).all()
                or not np.isfinite(replacement['normals']).all()
                or not np.allclose(np.linalg.norm(replacement['normals'],axis=-1),1.,atol=1e-5)
                or not np.array_equal(replacement['query'],geometry[key]['query'])):
            raise ValueError('dense surface/normal/flow identity mismatch: '+key)
        geometry[key]=replacement;seen.add(key)

def run():
    report={'commit':'28361dace28323a318f2d0bc3aa043bbae298b8a',
            'scope':'isolated source excerpts on synthetic data; no full dataset audit'}
    expected=[0,1,2,3,4,5,1,2,3,4,5];actual=[]
    for key in range(11):
        hand=np.zeros((2,11,3));valid=np.zeros((2,11),bool);valid[0,key]=True
        _,counts=_scaffold(hand,valid,np.array([-1.,-1.,-1.]),Policy())
        actual.append(int(counts[0].argmax()))
    assert actual==expected
    report['corrected_semantic_ids']={'actual':actual,'pass':True}
    valid=np.zeros((24,2,11),bool);valid[:,0]=True
    single=frame_mask(valid,[True,False]);assert single.all()
    partial=valid.copy();partial[5,0,3]=False
    p=frame_mask(partial,[True,False]);assert not p[5] and p.sum()==23
    disappeared=frame_mask(valid,[True,True]);assert not disappeared.any()
    empty=frame_mask(np.zeros_like(valid),[False,False]);assert not empty.any()
    report['corrected_future_hand_masks']={'single_hand_valid_frames':int(single.sum()),
        'one_missing_keypoint_valid_frames':int(p.sum()),'observed_side_disappeared_valid_frames':int(disappeared.sum()),
        'no_observed_hand_valid_frames':int(empty.sum()),'pass':True}
    # The geometry is deliberately modified AFTER a synthetic manifest exists,
    # retaining all current acceptance checks. No user's files are changed.
    rng=np.random.default_rng(0);surface=rng.uniform(-.05,.05,(512,3)).astype(np.float32)
    query=surface[:32].copy();normals=np.zeros_like(surface);normals[:,2]=1.
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp);manifest={'schema':SCHEMA,'status':'COMPLETED','objects':[{'key':'test/object','path':'g.npz'}]}
        (root/'manifest.json').write_text(json.dumps(manifest))
        np.savez(root/'g.npz',surface=surface,normals=normals,query=query)
        first={'test/object':{'query':query.copy()}};apply_surface_overlay(first,root/'manifest.json')
        tampered=surface.copy();tampered[32:,0]+=1.
        np.savez(root/'g.npz',surface=tampered,normals=normals,query=query)
        second={'test/object':{'query':query.copy()}};apply_surface_overlay(second,root/'manifest.json')
        change=float(np.abs(first['test/object']['surface']-second['test/object']['surface']).max())
        assert change>.99
        report['dense_overlay_payload_change_not_rejected']={'accepted_both':True,'max_surface_change_m':change,
             'query_exactly_unchanged':bool(np.array_equal(first['test/object']['query'],second['test/object']['query'])),
             'interpretation':'missing payload hash binding, NOT evidence that real production geometry changed'}
    return report
if __name__=='__main__':
    r=run();Path(__file__).with_name('data_repro_results.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(r,ensure_ascii=False,indent=2))
