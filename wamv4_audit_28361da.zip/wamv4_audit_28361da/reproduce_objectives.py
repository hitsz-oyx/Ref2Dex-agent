"""CPU numerical audit of loss algebra read at commit 28361da.

This is NOT a full repository test run. The functions below are source excerpts
from the pinned repository, with imports/normalization replaced by explicit
identity test fixtures. DDP averaging is emulated algebraically, not on GPUs.
"""
from pathlib import Path
import json
import torch
import torch.nn.functional as F

def masked_mean(values, mask, weights=None):
    if values.shape != mask.shape:
        raise ValueError("loss and validity shapes differ")
    if weights is None:
        weights = torch.ones_like(values)
    weights = torch.where(mask, weights, 0.)
    return (torch.where(mask, values, 0.) * weights).sum() / weights.sum().clamp_min(1e-8)

# Exact local C-loss algebra from v4/objectives.py; distributed collective branch
# is represented separately below to make the test independent of a process group.
def c_terms(logits, target, valid):
    contact = target[..., 0]
    bce = F.binary_cross_entropy_with_logits(logits[..., 0], contact, reduction="none")
    bce = torch.where(valid, bce, torch.zeros_like(bce))
    part_loss = -(target[..., 1:] * F.log_softmax(logits[..., 1:], dim=-1)).sum(-1)
    positive = valid & (contact > 0)
    part_loss = torch.where(positive, part_loss, torch.zeros_like(part_loss))
    return bce.sum(), valid.float().sum(), part_loss.sum(), positive.float().sum()

def local_c_loss(logits, target, valid):
    a,b,c,d = c_terms(logits,target,valid)
    return a/b.clamp_min(1.) + c/d.clamp_min(1.)

def run():
    torch.manual_seed(170)
    out = {"commit": "28361dace28323a318f2d0bc3aa043bbae298b8a", "torch": torch.__version__,
           "scope": "CPU algebraic reproduction on synthetic data; not full GPU or dataset validation"}

    # Equal-sized rank batches, differing valid hand counts; changing only the
    # placement of samples across ranks changes the current hand loss.
    # Four examples have squared errors [0,0,4,4] and counts [1,1,3,3].
    def hand_partition(groups):
        values = torch.tensor([[0.,0.,0.],[0.,0.,0.],[4.,4.,4.],[4.,4.,4.]])
        mask = torch.tensor([[1,0,0],[1,0,0],[1,1,1],[1,1,1]],dtype=torch.bool)
        return float(torch.stack([masked_mean(values[g],mask[g]) for g in groups]).mean())
    h_grouped = hand_partition([[0,1],[2,3]])
    h_mixed = hand_partition([[0,2],[1,3]])
    assert h_grouped == 2. and h_mixed == 3.
    out['hand_loss_rank_partition'] = {'grouped':h_grouped,'mixed':h_mixed,'global_masked_mean':3.}

    # Equal valid counts, but the motion weights differ by rank.
    weights = torch.tensor([[.1],[.1],[1.],[1.]])
    values = torch.tensor([[0.],[0.],[4.],[4.]])
    mask = torch.ones_like(values,dtype=torch.bool)
    def scene_partition(groups):
        return float(torch.stack([masked_mean(values[g],mask[g],weights[g]) for g in groups]).mean())
    s_grouped=scene_partition([[0,1],[2,3]])
    s_mixed=scene_partition([[0,2],[1,3]])
    out['scene_loss_rank_partition']={'grouped':s_grouped,'mixed':s_mixed,
                                      'global_weighted_mean':float(masked_mean(values,mask,weights))}
    assert abs(s_grouped-s_mixed)>1.

    # Regression of the FIXED C-DDP global-count implementation, including
    # different positive ratios and different valid counts.
    target=torch.zeros(4,1,24,128,7)
    valid=torch.ones(target.shape[:-1],dtype=torch.bool)
    valid[0,:,:,32:]=False
    target[0,:,:,:2,0:2]=1.
    target[1,:,:,:7,0]=1.;target[1,:,:,:7,3]=1.
    target[2,:,:,:40,0]=1.;target[2,:,:,:40,5]=1.
    logits=torch.randn_like(target,requires_grad=True)
    reference=local_c_loss(logits,target,valid)
    ref_grad,=torch.autograd.grad(reference,logits)
    n_edge=valid.sum().float();n_pos=(valid&(target[...,0]>0)).sum().float()
    losses=[];grads=[]
    for rank in range(2):
        sl=slice(2*rank,2*rank+2)
        local=logits[sl].detach().requires_grad_()
        a,_,c,_=c_terms(local,target[sl],valid[sl])
        loss=2*a/n_edge+2*c/n_pos
        grad,=torch.autograd.grad(loss,local)
        losses.append(loss.detach());grads.append(grad/2)
    discrepancy=float((torch.cat(grads)-ref_grad).abs().max())
    assert discrepancy < 1e-7
    out['corrected_c_ddp']={'full_loss':float(reference.detach()),'averaged_rank_loss':float(torch.stack(losses).mean()),
                            'max_gradient_difference':discrepancy,'pass':True}

    # Current evaluate() multiplies each microbatch's already-normalized C loss
    # by its SAMPLE count, not its positive-label count.
    # 32 windows; A predictions are bad on a sparse-contact family but good on
    # dense contact; B is uniformly moderate. Same windows, reordered only.
    target=torch.zeros(32,1,24,128,7)
    valid=torch.ones(target.shape[:-1],dtype=torch.bool)
    target[:16,:,:,0,0:2]=1.
    target[16:,:,:,:,0:2]=1.
    logits_a=torch.zeros_like(target);logits_b=torch.zeros_like(target)
    logits_a[:16,...,1]=-2.3905620875658995  # class0 CE ~4
    logits_a[16:,...,1]=3.1172090394179337  # class0 CE ~0.2
    logits_b[...,1]=1.176685782734542      # class0 CE ~0.935; just consistent moderate
    def report(logits,order):
        objective=0.;count=0
        for first in range(0,len(order),8):
            ix=order[first:first+8]
            objective += float(local_c_loss(logits[ix],target[ix],valid[ix]))*len(ix)
            count+=len(ix)
        return objective/count
    grouped=list(range(32))
    interleaved=[x for i in range(16) for x in (i,i+16)]
    a1,a2=report(logits_a,grouped),report(logits_a,interleaved)
    b1,b2=report(logits_b,grouped),report(logits_b,interleaved)
    assert (a1>b1) and (a2<b2)
    out['evaluation_order_and_checkpoint_ranking']={
        'A_grouped':a1,'A_interleaved':a2,'B_grouped':b1,'B_interleaved':b2,
        'winner_grouped':'B','winner_interleaved':'A',
        'A_global_objective':float(local_c_loss(logits_a,target,valid)),
        'B_global_objective':float(local_c_loss(logits_b,target,valid))}

    # Unconditional semantic probabilities sum to 1 even on no-contact queries.
    prediction=torch.tensor([0.,1/6,1/6,1/6,1/6,1/6,1/6])
    score=float(prediction.abs().mean())
    assert abs(score-1/7)<1e-7
    out['legacy_interaction_mae_noncontact_floor']={'perfect_no_contact_prediction':score,'expected_zero_for_valid_contact_error':0.}

    # Same current input and exactly same pre-mask prediction; only the future
    # supervision-valid mask changes. This is model.py's output mask expression.
    pre_mask=torch.ones(1,1,24,128,7)
    future_true=torch.ones(1,1,24,128,dtype=torch.bool)
    future_false=torch.zeros_like(future_true)
    y1=torch.where(future_true[...,None],pre_mask,0.)
    y2=torch.where(future_false[...,None],pre_mask,0.)
    out['forward_future_mask_dependency']={'max_output_change':float((y1-y2).abs().max()),
        'interpretation':'forward API depends on future supervision validity; not evidence of leaked future coordinates in encoder'}
    return out

if __name__=='__main__':
    report=run()
    p=Path(__file__).with_name('objective_repro_results.json')
    p.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(report,indent=2,ensure_ascii=False))
